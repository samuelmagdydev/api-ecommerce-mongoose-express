const categoryRoute = require("./categoryRoute");
// eslint-disable-next-line import/no-unresolved, import/extensions, node/no-missing-require
const subCategoryRoute = require("./subCategoryRoute"); // هنا لو اسم الملف غلط هيعمل المشكلة
const brandRoute = require("./brandRoute");
const productRoute = require("./productRoute");
const userRoute = require("./userRoute");
const authRoute = require("./authRoute");
const reviewRoute = require("./reviewRoute");
const wishlistRoute = require("./wishlistRoute");
const addressRoute = require("./addressRoute");
const couponRoute = require("./couponRoute");
const cartRoute = require("./cartRoute");
const orderRoute = require("./orderRoute");

const mountRoutes = (app) => {
  console.log("🚀 mounting categoryRoute");
  app.use("/api/v1/categories", categoryRoute);

  console.log("🚀 mounting subCategoryRoute");
  app.use("/api/v1/subcategories", subCategoryRoute); // << هنا الغلط ممكن يكون الاسم

  console.log("🚀 mounting brandRoute");
  app.use("/api/v1/brands", brandRoute);

  console.log("🚀 mounting productRoute");
  app.use("/api/v1/products", productRoute);

  console.log("🚀 mounting userRoute");
  app.use("/api/v1/users", userRoute);

  console.log("🚀 mounting authRoute");
  app.use("/api/v1/auth", authRoute);

  console.log("🚀 mounting reviewRoute");
  app.use("/api/v1/reviews", reviewRoute);

  console.log("🚀 mounting wishlistRoute");
  app.use("/api/v1/wishlist", wishlistRoute);

  console.log("🚀 mounting addressRoute");
  app.use("/api/v1/addresses", addressRoute);

  console.log("🚀 mounting couponRoute");
  app.use("/api/v1/coupon", couponRoute);

  console.log("🚀 mounting cartRoute");
  app.use("/api/v1/cart", cartRoute);

  console.log("🚀 mounting orderRoute");
  app.use("/api/v1/orders", orderRoute);
};

module.exports = mountRoutes;
