const path = require("path");
const express = require("express");
const dotenv = require("dotenv");
const morgan = require("morgan");
// eslint-disable-next-line import/no-extraneous-dependencies
const cors = require("cors");
const dbConnection = require("./config/database");

dotenv.config({ path: "config.env" });
const ApiError = require("./utils/apiError");
const globalError = require("./middlewares/erroemiddleware");
const mountRoutes = require("./Routes");

//connect to database
dbConnection();
//express app
const app = express();

app.use(cors());

app.options("*", cors()); // for preflight requests

//Middlewares

app.use(express.json());
app.use(express.static(path.join(__dirname, "uploads")));

if (process.env.NODE_ENV === "development") {
  app.use(morgan("dev"));
  console.log(`mode : ${process.env.NODE_ENV}`);
}
//MountRoutes

mountRoutes(app);

// app.all("*", (req, res, next) => {
//   const error = new ApiError(`Can't find ${req.originalUrl} on this server!`, 404);
//   next(error);
// });

//Global errorHandling Middleware
app.use(globalError);

const PORT = process.env.PORT || 8000;
const server = app.listen(PORT, () => {
  console.log(`App Running On port ${PORT}`);
});

//handel rejection outside express
process.on("unhandledRejection", (err) => {
  console.error(`unhandledRejection Errors : ${err.name} | ${err.message}`);
  server.close(() => {
    console.error(`Shutting Down...`);

    process.exit(1);
  });
});
